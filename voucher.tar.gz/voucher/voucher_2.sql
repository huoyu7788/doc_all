call fin_voucher_data(date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('RE',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('JISHOU_RE',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('ZV2',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('RE_FC',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('RV_FC',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('ZV2_CY',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('ZV2_LS',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('KA_ZV2',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('BSDS_DR',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('BSDS_RV',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('BSDS_WE',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('KA_RV',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('RV',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('THIRD',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('CASH',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('BANK',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('THIRD_BUG',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('CASH_BUG',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

call fin_voucher('BANK_BUG',date_sub(curdate(),interval 2 day),date_sub(curdate(),interval 2 day));

-- call fin_voucher('KZ',date_sub(curdate(),interval 1 day),date_sub(curdate(),interval 1 day));

call fin_voucher('ALL','','');

quit


